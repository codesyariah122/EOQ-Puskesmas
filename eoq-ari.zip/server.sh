#!/bin/bash

port=4041
php -S localhost:$port
