<div class="flex justify-center">
	<div>
		<nav aria-label="Page navigation example">
			<ul id="pagination" class="inline-flex -space-x-px text-sm"></ul>
		</nav>
	</div>
</div>