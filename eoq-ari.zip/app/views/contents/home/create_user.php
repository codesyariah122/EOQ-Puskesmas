

<section id="first" >
	<div class="grid grid-cols-1 py-24 justify-items-stretch">		
		<div class="col-span-full justify-self-center">
			<h1 class="text-3xl font-bold text-gray-800">Create New User</h1>
		</div>
	</div>
</section>
