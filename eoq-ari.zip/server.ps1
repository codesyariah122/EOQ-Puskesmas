$port=4041
$phpExecutable = "C:\xampp\php\php.exe"
& $phpExecutable -S localhost:$port
